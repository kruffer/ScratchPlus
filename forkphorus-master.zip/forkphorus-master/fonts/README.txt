Fonts used by forkphorus to render text in SVGs. All fonts belong to their respective owners (see below).

-----

Donegal One
Copyright (c) 2012, Sorkin Type Co (www.sorkintype.com) with Reserved Font Name 'Donegal'
SIL Open Font License, 1.1
https://fonts.google.com/specimen/Donegal+One

Gloria Hallelujah
Copyright (c) 2010, Kimberly Geswein (kimberlygeswein.com kimberlygeswein@gmail.com)
SIL Open Font License, 1.1
https://fonts.google.com/specimen/Gloria+Hallelujah

Grand9K-Pixel
Copyright (c) 2013, Grand Chaos Productions. Some Rights Reserved.
Creative Commons (CC-BY-SA 3.0)
https://www.dafont.com/grand9k-pixel.font#top

Griffy
Copyright (c) 2012 by Font Diner, Inc DBA Neapolitan (diner@fontdiner.com) with Reseved Font Name "Griffy"
SIL Open Font License, 1.1
https://fonts.google.com/specimen/Griffy

Handlee
Copyright (c) 2011, Admix Designs (http://www.admixdesigns.com/) with Reserved Font Name Handlee.
SIL Open Font License, 1.1
https://fonts.google.com/specimen/Handlee

Knewave
Copyright (c) 2011 by Tyler Finck. All rights reserved.
SIL Open Font License, 1.1
https://fonts.google.com/specimen/Knewave

Mystery Quest
Copyright (c) 2012 by Font Diner, Inc DBA Sideshow (diner@fontdiner.com) with Reseved Font Name "Mystery Quest"
SIL Open Font License, 1.1
https://fonts.google.com/specimen/Mystery+Quest

Noto Sans
NotoSans-Regular.ttf: Copyright 2012 Google Inc. All Rights Reserved.
Apache License, version 2.0
https://fonts.google.com/specimen/Noto+Sans

Permanent Marker
Copyright (c) 2010 by Font Diner, Inc. All rights reserved.
Apache License, version 2.0
https://fonts.google.com/specimen/Permanent+Marker

Source Serif Pro
Copyright 2014 Adobe Systems Incorporated. All Rights Reserved.
SIL Open Font License, 1.1
https://fonts.google.com/specimen/Source+Serif+Pro
